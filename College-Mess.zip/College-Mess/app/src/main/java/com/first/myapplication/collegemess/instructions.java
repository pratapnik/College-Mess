package com.first.myapplication.collegemess;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class instructions extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instructions);
    }
}
