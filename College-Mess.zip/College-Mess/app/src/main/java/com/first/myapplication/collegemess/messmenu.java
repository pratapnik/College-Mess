package com.first.myapplication.collegemess;

public class messmenu {

    String menuItem;
    public messmenu(){

    }

    public messmenu(String menuItem) {
        this.menuItem = menuItem;
    }

    public String getMenuItem() {
        return menuItem;
    }
}
